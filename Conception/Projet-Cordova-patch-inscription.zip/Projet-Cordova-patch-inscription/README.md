# Equipe
nicolasroseau971@gmail.com
francoise.provot@gmail.com
bardoumathieu.fac@gmail.com
moco.vincent@gmail.com
blackcrown971@gmail.com
kennyljd@gmail.com

# Organisation
- Front End : Cordova et Ajax
- Back End : Webservice Django
- BDD : MongoDB

# Exemple Utilisation WS
`curl -X POST -H 'Accept-Language: JSON' -i 'http://127.0.0.1:8000/runners/list/' 
--data '{"pseudo": "test2", "mail": "test2@mail.com", "password": "test2"}'`

